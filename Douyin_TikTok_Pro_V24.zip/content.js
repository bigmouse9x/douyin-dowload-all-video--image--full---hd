console.log("Douyin & TikTok Core Active");

// ==========================================
// 1. MODULE DOUYIN
// ==========================================
function sleep(ms){return new Promise(r=>setTimeout(r,ms));}

function getHighestBitrateVideo(item){
 try{
   if(item.video?.bit_rate?.length){
      const sorted = [...item.video.bit_rate].sort((a,b)=> (b.bit_rate || 0) - (a.bit_rate || 0));
      const best = sorted[0];
      const url = best?.play_addr?.url_list?.[0];
      if(url){
        return { url, quality: best?.gear_name || best?.quality_type || "HD" };
      }
   }
   const fallback = item.video?.play_addr?.url_list?.[0];
   if(fallback){
      return { url:fallback, quality:"Standard" };
   }
 }catch(e){
   console.error(e);
 }
 return null;
}

function getHighestImage(img){
 return (img?.url_list?.[0] || img?.download_url_list?.[0] || "");
}

async function getMedia(){
 const sec_user_id = location.pathname.replace("/user/","");
 const result = [];
 let max_cursor = 0;
 let hasMore = 1;

 while(hasMore == 1){
   const url = `https://www.douyin.com/aweme/v1/web/aweme/post/?device_platform=webapp&aid=6383&channel=channel_pc_web&sec_user_id=${sec_user_id}&max_cursor=${max_cursor}&count=20&version_code=170400&version_name=17.4.0`;
   try{
     const res = await fetch(url,{ credentials:"include" });
     const data = await res.json();
     if(!data.aweme_list) break;

     hasMore = data.has_more;
     max_cursor = data.max_cursor;

     for(const item of data.aweme_list){
        try{
          const title = item.desc || "Douyin Media";
          const hasImages = Array.isArray(item.images) && item.images.length > 0;
          const musicUrl = item.music?.play_url?.url_list?.[0];

          // IMAGE POSTS
          if(hasImages){
             item.images.forEach((img,index)=>{
                const imageUrl = getHighestImage(img);
                if(imageUrl){
                  result.push({ type:"image", quality:"HD", title:`${title}_${index+1}`, cover:imageUrl, mediaUrl:imageUrl });
                }
             });
             if(musicUrl){
                result.push({ type:"mp3", quality:"Audio", title:title + "_audio", cover:item.images?.[0]?.url_list?.[0] || "", mediaUrl:musicUrl });
             }
          }
          // VIDEO POSTS
          else if(item.video){
             const bestVideo = getHighestBitrateVideo(item);
             if(bestVideo){
               result.push({ type:"video", quality:bestVideo.quality, title, cover: item.video?.cover?.url_list?.[0] || "", mediaUrl:bestVideo.url });
             }
             if(musicUrl){
                result.push({ type:"mp3", quality:"Audio", title:title + "_audio", cover: item.video?.cover?.url_list?.[0] || "", mediaUrl:musicUrl });
             }
          }
        }catch(e){
          console.error(e);
        }
     }
     await sleep(1000);
   }catch(e){
      console.error(e);
      break;
   }
 }

 const unique = [];
 result.forEach(v=>{
   if(!unique.find(x=> x.mediaUrl === v.mediaUrl && x.type === v.type)){
      unique.push(v);
   }
 });

 chrome.storage.local.set({ douyinMedia: unique });
 console.log("Saved HD media:", unique.length);
}

// ==========================================
// 2. BỘ ĐỊNH TUYẾN MESSAGE (DOUYIN & TIKTOK)
// ==========================================
chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
 if(req.action === "scanMedia"){
   getMedia().then(() => sendResponse({status: "done"}));
 }
 else if (req.action === "scanTikTok") {
   // BỔ SUNG: Bắt cả link /video/, /v/ và /photo/ (cho bài đăng ảnh)
   const links = Array.from(document.querySelectorAll('a'))
       .map(a => a.href)
       .filter(href => href && (href.includes('/video/') || href.includes('/v/') || href.includes('/photo/')));
   const uniqueLinks = [...new Set(links.map(l => l.split('?')[0]))];
   sendResponse({ links: uniqueLinks });
 }
 return true;
});