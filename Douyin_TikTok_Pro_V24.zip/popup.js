// =====================================
// DOUYIN
// =====================================
document.getElementById("saveTab").addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
  if (!tab || !tab.url.includes("douyin.com")) {
    alert("❌ Vui lòng mở đúng tab trang cá nhân Douyin!"); return;
  }
  chrome.storage.local.set({ douyinTabId: tab.id, douyinMedia: [] }); 
  alert("Đã lưu tab Douyin và Dọn dẹp bộ nhớ cũ! Giờ hãy bấm Bước 2 (Mở bảng Dashboard) để quét.");
});

document.getElementById("openDashboard").addEventListener("click", () => {
  chrome.tabs.create({url: chrome.runtime.getURL("dashboard.html")});
});

// =====================================
// TIKTOK (AUTO-UPDATE LINK CHO SIDE PANEL)
// =====================================
function updateTikTokUrlInput(tab) {
    if(tab && tab.url && tab.url.includes("tiktok.com")) {
        const url = tab.url;
        if(url.includes("/video/") || url.includes("/v/") || url.includes("vt.tiktok.com") || url.includes("/photo/")) {
            document.getElementById("tk-url").value = url;
        } else {
            document.getElementById("tk-url").placeholder = "⚠ Hãy mở 1 video cụ thể để tự nhận link!";
            document.getElementById("tk-url").value = "";
        }
    }
}

chrome.tabs.query({active: true, currentWindow: true}, (tabs) => { updateTikTokUrlInput(tabs[0]); });
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => { if (changeInfo.status === 'complete') updateTikTokUrlInput(tab); });
chrome.tabs.onActivated.addListener(async (activeInfo) => {
    const tab = await chrome.tabs.get(activeInfo.tabId);
    updateTikTokUrlInput(tab);
});

// =====================================
// TÍNH NĂNG: XÓA TRÍ NHỚ TIKTOK
// =====================================
document.getElementById("tk-clear-memory").addEventListener("click", () => {
    if (confirm("Bạn có chắc muốn xóa bộ nhớ? Hệ thống sẽ quên các video TikTok bạn đã xuất.")) {
        chrome.storage.local.set({ tiktokMemory: [] }, () => {
            alert("Đã xóa sạch trí nhớ TikTok!");
        });
    }
});

// =====================================
// TIKTOK (TẢI LẺ 1 BÀI)
// =====================================
document.getElementById("tk-download").addEventListener("click", () => {
  const url = document.getElementById("tk-url").value.trim();
  const status = document.getElementById("status-msg");
  const resultBox = document.getElementById("dl-result");

  if(!url) { status.innerText = "Bạn chưa dán link, hoặc chưa mở video/ảnh!"; status.style.color = "#ff3b30"; return; }
  status.innerText = "Đang lấy dữ liệu..."; status.style.color = "#aaa"; resultBox.innerHTML = "";

  chrome.runtime.sendMessage({ type: 'TIKWM_FETCH', url: url }, res => {
      if (chrome.runtime.lastError || !res || !res.ok) {
          status.innerText = "Lỗi kết nối Server: " + (res?.error || "Link không tồn tại"); status.style.color = "#ff3b30"; return;
      }
      const d = res.data; const rows = [];
      if (d.hdplay) rows.push({ label: 'Video (HD, No Logo)', href: d.hdplay, ext: 'mp4' });
      if (d.play && !d.hdplay) rows.push({ label: 'Video (No Logo)', href: d.play, ext: 'mp4' });
      if (d.wmplay) rows.push({ label: 'Video (Có Logo)', href: d.wmplay, ext: 'mp4' });
      if (d.music)  rows.push({ label: 'Audio (MP3)', href: d.music, ext: 'mp3' });
      if (d.images && Array.isArray(d.images)) { d.images.forEach((img, i) => rows.push({ label: `Ảnh ${i+1}/${d.images.length}`, href: img, ext: 'jpg' })); }
      if (rows.length === 0) { status.innerText = "Không tìm thấy file nào."; status.style.color = "#ff3b30"; return; }
      
      status.innerText = "Thành công! Bấm để tải:"; status.style.color = "#00ff99";
      rows.forEach(r => {
          const btn = document.createElement("div"); btn.className = "dl-item";
          let icon = r.ext === 'mp3' ? "🎵" : r.ext === 'jpg' ? "🖼️" : "🎥";
          let finalUrl = r.href.startsWith('/') ? 'https://tikwm.com' + r.href : r.href;
          btn.innerHTML = `<span>${icon} ${r.label}</span> <span>⬇ Tải</span>`;
          btn.onclick = () => {
              btn.style.opacity = "0.5";
              chrome.runtime.sendMessage({ type: 'DOWNLOAD_FILE', url: finalUrl, filename: `tiktok_${Date.now()}.${r.ext}` }, () => {
                  setTimeout(() => { btn.style.opacity = "1"; }, 500);
              });
          };
          resultBox.appendChild(btn);
      });
  });
});

// =====================================
// TIKTOK (BATCH XUẤT TXT TÍCH HỢP TRÍ NHỚ PHÂN ĐỢT)
// =====================================
function downloadBlob(content, filename) {
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    chrome.downloads.download({ url: url, filename: filename, saveAs: false });
}

async function batchExportTikTok(type) {
  const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
  if (!tab || !tab.url.includes("tiktok.com")) { alert("❌ Bạn phải đang ở trên trang TikTok!"); return; }
  
  const statusSpan = document.getElementById(`status-${type}`);
  
  if (statusSpan.dataset.running === "true") { alert("⏳ Tiến trình đang chạy!"); return; }
  
  const batchSize = parseInt(document.getElementById("tk-batch-size").value) || 100;
  
  statusSpan.dataset.running = "true";
  statusSpan.style.color = "#aaa"; 
  statusSpan.innerText = `- Đang lọc link...`;
  
  chrome.tabs.sendMessage(tab.id, {action: "scanTikTok"}, async (res) => {
      if (chrome.runtime.lastError || !res || !res.links) { 
          statusSpan.innerText = `- Lỗi kết nối!`; statusSpan.dataset.running = "false"; return; 
      }
      
      const rawLinks = res.links; 
      
      // BƯỚC 1: LẤY TRÍ NHỚ & LỌC BỎ LINK CŨ
      const storage = await chrome.storage.local.get("tiktokMemory");
      const memory = new Set(storage.tiktokMemory || []);
      
      const newLinks = rawLinks.filter(link => !memory.has(link));
      
      if (newLinks.length === 0) {
          statusSpan.innerText = `- ✅ Đã xuất hết! Lướt trang thêm`; 
          statusSpan.style.color = "#ffb700";
          statusSpan.dataset.running = "false";
          return;
      }
      
      // BƯỚC 2: CẮT ĐÚNG SỐ LƯỢNG MỘT ĐỢT
      const linksToProcess = newLinks.slice(0, batchSize);
      const total = linksToProcess.length;
      
      let extractedVideos = [];
      let extractedImages = [];
      let extractedMusic = [];
      
      // BƯỚC 3: GIẢI MÃ API
      for (let i = 0; i < total; i++) {
          statusSpan.innerText = `- API: ${i + 1}/${total}`;
          try {
              const apiRes = await new Promise(r => chrome.runtime.sendMessage({ type: 'TIKWM_FETCH', url: linksToProcess[i] }, r));
              if (apiRes && apiRes.ok && apiRes.data) {
                  const d = apiRes.data;
                  if (type === 'video' || type === 'all') {
                      let url = d.hdplay || d.play;
                      if (url) extractedVideos.push(url.startsWith('/') ? 'https://tikwm.com' + url : url);
                  }
                  if (type === 'music' || type === 'all') {
                      let url = d.music;
                      if (url) extractedMusic.push(url.startsWith('/') ? 'https://tikwm.com' + url : url);
                  }
                  if (type === 'image' || type === 'all') {
                      if (d.images && Array.isArray(d.images)) d.images.forEach(img => extractedImages.push(img));
                  }
              }
          } catch(e) {}
          await new Promise(r => setTimeout(r, 1200)); 
      }
      
      let count = 0;

      if (type === 'video' || type === 'all') {
          extractedVideos = [...new Set(extractedVideos)];
          if (extractedVideos.length > 0) { downloadBlob(extractedVideos.join('\n'), `TikTok_Video_${Date.now()}.txt`); count += extractedVideos.length; }
      }
      if (type === 'music' || type === 'all') {
          extractedMusic = [...new Set(extractedMusic)];
          if (extractedMusic.length > 0) { downloadBlob(extractedMusic.join('\n'), `TikTok_Music_${Date.now()}.txt`); count += extractedMusic.length; }
      }
      if (type === 'image' || type === 'all') {
          extractedImages = [...new Set(extractedImages)];
          if (extractedImages.length > 0) { downloadBlob(extractedImages.join('\n'), `TikTok_Image_${Date.now()}.txt`); count += extractedImages.length; }
      }

      if (count > 0) {
          statusSpan.innerText = `- ✅ Hoàn tất đợt (${total})`; 
          statusSpan.style.color = "#00ff99";
          
          // BƯỚC 4: GHI NHỚ LẠI NHỮNG LINK VỪA XUẤT ĐỂ ĐỢT SAU BỎ QUA
          linksToProcess.forEach(l => memory.add(l));
          await chrome.storage.local.set({ tiktokMemory: Array.from(memory) });
      } else {
          statusSpan.innerText = `- ❌ Lỗi giải mã!`; 
          statusSpan.style.color = "#ff3b30";
      }
      
      statusSpan.dataset.running = "false";
  });
}

document.getElementById("tk-scan-export-video").addEventListener("click", () => batchExportTikTok('video'));
document.getElementById("tk-scan-export-image").addEventListener("click", () => batchExportTikTok('image'));
document.getElementById("tk-scan-export-music").addEventListener("click", () => batchExportTikTok('music'));
document.getElementById("tk-scan-export-all").addEventListener("click", () => batchExportTikTok('all'));

// =====================================
// TIKTOK (XUẤT LINK GỐC PROFILE CŨNG TÍCH HỢP TRÍ NHỚ)
// =====================================
document.getElementById("tk-scan-raw-export").addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
  if (!tab || !tab.url.includes("tiktok.com")) { 
    alert("❌ Bạn phải đang mở một trang hồ sơ TikTok!"); return; 
  }
  
  const status = document.getElementById("status-msg");
  const batchSize = parseInt(document.getElementById("tk-batch-size").value) || 100;
  
  status.style.color = "#aaa";
  status.innerText = "Đang lọc link mới...";
  
  chrome.tabs.sendMessage(tab.id, {action: "scanTikTok"}, async (res) => {
      if (chrome.runtime.lastError || !res || !res.links) { alert("Lỗi: Hãy tải lại trang (F5)!"); return; }
      
      const rawLinks = res.links;
      
      const storage = await chrome.storage.local.get("tiktokMemory");
      const memory = new Set(storage.tiktokMemory || []);
      
      const newLinks = rawLinks.filter(link => !memory.has(link));
      
      if (newLinks.length === 0) {
          status.innerText = "✅ Tất cả link trên màn hình đều đã xuất. Hãy cuộn chuột load thêm video!";
          status.style.color = "#ffb700";
          return;
      }
      
      const linksToProcess = newLinks.slice(0, batchSize);
      
      if (linksToProcess.length > 0) {
          downloadBlob(linksToProcess.join('\n'), `TikTok_RawLinks_${Date.now()}.txt`);
          
          status.innerText = `✅ Đã xuất Đợt ${linksToProcess.length} link gốc mới!`;
          status.style.color = "#00ff99";
          
          linksToProcess.forEach(l => memory.add(l));
          await chrome.storage.local.set({ tiktokMemory: Array.from(memory) });
      }
  });
});