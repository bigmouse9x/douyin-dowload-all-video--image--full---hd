const grid = document.getElementById("grid");

function setStatus(t) {
  document.getElementById("status").innerText = t;
}

function clearChecks() {
  document.querySelectorAll(".mediaCheck").forEach(c => c.checked = false);
}

function load() {
  grid.innerHTML = "";
  chrome.storage.local.get("douyinMedia", (res) => {
    const media = res.douyinMedia || [];
    let downloadedCount = media.filter(m => m.downloaded).length;
    setStatus(`Tìm thấy ${media.length} Media (Đã tải xong: ${downloadedCount} | Còn lại: ${media.length - downloadedCount})`);
    
    media.forEach((item, index) => {
      const card = document.createElement("div");
      card.className = "card";
      
      // Xử lý giao diện cho những file đã tải ở các đợt trước
      let isDownloaded = item.downloaded ? true : false;
      if(isDownloaded) {
          card.classList.add("downloaded-item");
          card.style.opacity = "0.3"; // Làm mờ đi
      }

      let badge = "🎥 VIDEO";
      if (item.type === "image") badge = "🖼 IMAGE";
      if (item.type === "mp3") badge = "🎵 MP3";

      card.innerHTML = `
        <img src="${item.cover}">
        <div class="info">
          <div class="badge">${badge}</div>
          <div class="quality">
            Quality: ${item.quality || "HD"} ${isDownloaded ? "<b>(ĐÃ TẢI)</b>" : ""}
          </div>
          <div class="title">
            ${escapeHtml(item.title)}
          </div>
          <label>
          <input type="checkbox" class="mediaCheck" data-type="${item.type}" data-index="${index}" ${isDownloaded ? "disabled" : ""}>
          Select
          </label>
        </div>
      `;
      grid.appendChild(card);
    });
  });
}

// ==========================================
// TÍNH NĂNG CHỌN THEO ĐỢT (BATCH SELECTION)
// ==========================================
const batchSizeInput = document.getElementById("batchSize");
const selectBatchBtn = document.getElementById("selectBatchBtn");

if (batchSizeInput && selectBatchBtn) {
    batchSizeInput.addEventListener("input", (e) => {
        let size = e.target.value || 0;
        selectBatchBtn.innerText = `Chọn [${size}] file chưa tải tiếp theo`;
    });

    selectBatchBtn.addEventListener("click", () => {
        clearChecks();
        const limit = parseInt(batchSizeInput.value) || 200;
        let selectedCount = 0;
        
        // Quét và chọn đúng giới hạn những file CHƯA BỊ MỜ (chưa tải)
        const allChecks = document.querySelectorAll(".mediaCheck");
        for (let i = 0; i < allChecks.length; i++) {
            if (selectedCount >= limit) break; // Đủ số lượng thì dừng
            
            let c = allChecks[i];
            if (!c.disabled) { // Nếu checkbox không bị khóa (tức là chưa tải)
                c.checked = true;
                selectedCount++;
            }
        }
        
        if (selectedCount === 0) {
            alert("Toàn bộ kênh này đã được tải hết! Không còn file mới.");
        } else {
            setStatus(`Đã chọn thành công đợt ${selectedCount} file tiếp theo.`);
        }
    });
}
// ==========================================

document.getElementById("scanBtn").addEventListener("click", () => {
  chrome.storage.local.get("douyinTabId", (res) => {
    const tabId = res.douyinTabId;
    if (!tabId) { alert("Save Douyin tab first"); return; }
    setStatus("Scanning highest quality media...");
    chrome.tabs.sendMessage(tabId, { action: "scanMedia" }, () => {
      setTimeout(() => { load(); setStatus("HD scan complete"); }, 7000);
    });
  });
});

document.getElementById("refreshBtn").addEventListener("click", load);

// Các nút chọn cơ bản cũng sẽ thông minh né các file đã tải ra
document.getElementById("selectAllBtn").addEventListener("click", () => {
  document.querySelectorAll(".mediaCheck:not(:disabled)").forEach(c => c.checked = true);
});
document.getElementById("selectVideoBtn").addEventListener("click", () => {
  clearChecks(); document.querySelectorAll('.mediaCheck[data-type="video"]:not(:disabled)').forEach(c => c.checked = true);
});
document.getElementById("selectImageBtn").addEventListener("click", () => {
  clearChecks(); document.querySelectorAll('.mediaCheck[data-type="image"]:not(:disabled)').forEach(c => c.checked = true);
});
document.getElementById("selectMp3Btn").addEventListener("click", () => {
  clearChecks(); document.querySelectorAll('.mediaCheck[data-type="mp3"]:not(:disabled)').forEach(c => c.checked = true);
});

// ==========================================
// HÀM TẢI (LƯU LẠI BỘ NHỚ FILE ĐÃ TẢI)
// ==========================================
function executeDownload() {
  chrome.storage.local.get("douyinMedia", (res) => {
    const media = res.douyinMedia || [];
    const checks = document.querySelectorAll(".mediaCheck");
    let count = 0;
    let delay = 0;
    let isModified = false;

    checks.forEach(c => {
      if (c.checked) {
        const index = parseInt(c.dataset.index);
        const item = media[index];
        if (!item) return;

        let ext = "mp4";
        if (item.type === "image") ext = "jpg";
        if (item.type === "mp3") ext = "mp3";

        let finalUrl = item.mediaUrl || "";
        if (finalUrl.startsWith("//")) finalUrl = "https:" + finalUrl;

        setTimeout(() => {
          chrome.downloads.download({
            url: finalUrl,
            filename: `douyin/${sanitize(item.title)}.${ext}`,
            saveAs: false,
            conflictAction: "uniquify"
          });
        }, delay);
        
        // ĐÁNH DẤU LƯU TRỮ LÀ ĐÃ TẢI
        media[index].downloaded = true;
        isModified = true;
        
        // Cập nhật giao diện mờ đi ngay lập tức
        c.checked = false;
        c.disabled = true;
        const card = c.closest('.card');
        if (card) {
            card.classList.add("downloaded-item");
            card.style.opacity = "0.3";
        }

        delay += 400;
        count++;
      }
    });
    
    // Ghi đè bộ nhớ mới vào Chrome
    if (isModified) {
        chrome.storage.local.set({ douyinMedia: media });
    }
    
    setStatus(`Đang xuất ${count} file... Những file này đã được lưu vào bộ nhớ Đã Tải để bỏ qua ở đợt sau.`);
  });
}

document.getElementById("downloadBtn").addEventListener("click", () => {
  if (!window.__douyinDisclaimerAccepted) {
    const modal = document.getElementById("disclaimerModal");
    if (modal) modal.classList.remove("hidden");
    return;
  }
  executeDownload();
});

function sanitize(str) { return (str || "douyin_media").replace(/[\r\n]+/g, " ").replace(/[\\\\/:*?"<>|]/g, "").slice(0, 80).trim(); }
function escapeHtml(str) { return (str || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }

load();

// TÍCH HỢP TẤT CẢ SỰ KIỆN VÀO LUỒNG TẢI TRANG
window.addEventListener("DOMContentLoaded", () => {
  const modal = document.getElementById("disclaimerModal");
  const agree = document.getElementById("agreeCheck");
  const startBtn = document.getElementById("startDownloadBtn");
  const cancelBtn = document.getElementById("closeModalBtn");

  const clearBtn = document.getElementById("clearOldMediaBtn");
  if (clearBtn) {
    clearBtn.onclick = () => {
      if (confirm("Nếu bạn bấm Xóa, hệ thống sẽ quên luôn cả trí nhớ của những file đã tải. Tiếp tục?")) {
        chrome.storage.local.set({ douyinMedia: [] }, () => {
          alert("Đã xóa sạch bộ nhớ tạm!");
          location.reload(); 
        });
      }
    };
  }

  if (!modal) return;
  window.__douyinDisclaimerAccepted = false;
  startBtn.disabled = true;

  agree.addEventListener("change", () => {
    if (agree.checked) { startBtn.disabled = false; startBtn.classList.add("enabled"); } 
    else { startBtn.disabled = true; startBtn.classList.remove("enabled"); }
  });
  cancelBtn.addEventListener("click", () => { modal.classList.add("hidden"); });

  startBtn.addEventListener("click", () => {
    if (!agree.checked) return;
    window.__douyinDisclaimerAccepted = true;
    modal.classList.add("hidden");
    executeDownload();
    setTimeout(() => { window.__douyinDisclaimerAccepted = false; }, 1000);
  });
});