chrome.runtime.onInstalled.addListener(() => {
  console.log("Douyin & TikTok Pro SidePanel Active");
  // Lệnh bắt buộc để mở Side Panel khi click vào Icon
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch((error) => console.error(error));
});

// Lõi xử lý API tải TikTok ngầm
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'TIKWM_FETCH') {
    fetchTikwm(msg.url)
      .then(data => sendResponse({ ok: true, data }))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true; 
  }
  if (msg.type === 'DOWNLOAD_FILE') {
    chrome.downloads.download({ url: msg.url, filename: msg.filename || 'media_file', saveAs: false });
    sendResponse({ ok: true }); 
    return true;
  }
});

async function fetchTikwm(tiktokUrl) {
  const body = new URLSearchParams({ url: tiktokUrl, hd: '1' });
  const res = await fetch('https://tikwm.com/api/', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: body.toString()
  });
  if (!res.ok) throw new Error('HTTP ' + res.status);
  const json = await res.json();
  if (json.code !== 0) throw new Error(json.msg || 'API error');
  return json.data;
}