
const grid=document.getElementById("grid");

function setStatus(t){
 document.getElementById("status").innerText=t;
}

function clearChecks(){
 document.querySelectorAll(".mediaCheck")
 .forEach(c=>c.checked=false);
}

function load(){

 grid.innerHTML="";

 chrome.storage.local.get("douyinMedia",(res)=>{

   const media=res.douyinMedia||[];

   setStatus(`HD Media found: ${media.length}`);

   media.forEach((item,index)=>{

      const card=document.createElement("div");

      card.className="card";

      let badge="🎥 VIDEO";

      if(item.type==="image") badge="🖼 IMAGE";
      if(item.type==="mp3") badge="🎵 MP3";

      card.innerHTML=`
        <img src="${item.cover}">

        <div class="info">

          <div class="badge">${badge}</div>

          <div class="quality">
            Quality: ${item.quality || "HD"}
          </div>

          <div class="title">
            ${escapeHtml(item.title)}
          </div>

          <label>
          <input
            type="checkbox"
            class="mediaCheck"
            data-type="${item.type}"
            data-index="${index}"
          >
          Select
          </label>

        </div>
      `;

      grid.appendChild(card);
   });
 });
}

document.getElementById("scanBtn")
.addEventListener("click",()=>{

 chrome.storage.local.get("douyinTabId",(res)=>{

   const tabId=res.douyinTabId;

   if(!tabId){
      alert("Save Douyin tab first");
      return;
   }

   setStatus("Scanning highest quality media...");

   chrome.tabs.sendMessage(
      tabId,
      {action:"scanMedia"},
      ()=>{

        setTimeout(()=>{
          load();
          setStatus("HD scan complete");
        },7000);

      }
   );
 });
});

document.getElementById("refreshBtn")
.addEventListener("click",load);

document.getElementById("selectAllBtn")
.addEventListener("click",()=>{
 document.querySelectorAll(".mediaCheck")
 .forEach(c=>c.checked=true);
});

document.getElementById("selectVideoBtn")
.addEventListener("click",()=>{
 clearChecks();
 document.querySelectorAll('.mediaCheck[data-type="video"]')
 .forEach(c=>c.checked=true);
});

document.getElementById("selectImageBtn")
.addEventListener("click",()=>{
 clearChecks();
 document.querySelectorAll('.mediaCheck[data-type="image"]')
 .forEach(c=>c.checked=true);
});

document.getElementById("selectMp3Btn")
.addEventListener("click",()=>{
 clearChecks();
 document.querySelectorAll('.mediaCheck[data-type="mp3"]')
 .forEach(c=>c.checked=true);
});



document.getElementById("downloadBtn")
.addEventListener("click",async()=>{

 if(!window.__douyinDisclaimerAccepted){

    const modal=document.getElementById("disclaimerModal");

    if(modal){
       modal.classList.remove("hidden");
    }

    return;
 }


 chrome.storage.local.get("douyinMedia",(res)=>{

   const media=res.douyinMedia||[];

   const checks=document.querySelectorAll(".mediaCheck");

   let count = 0;
   let delay = 0;

   checks.forEach(c=>{

      if(c.checked){

         const item=media[parseInt(c.dataset.index)];

         let ext="mp4";

         if(item.type==="image") ext="jpg";
         if(item.type==="mp3") ext="mp3";

         setTimeout(()=>{

            chrome.downloads.download({
               url:item.mediaUrl,
               filename:`douyin/${sanitize(item.title)}.${ext}`,
               saveAs:false,
               conflictAction:"uniquify"
            });

         },delay);

         delay += 400;
         count++;
      }
   });

   setStatus(`Started downloading ${count} files`);
 });
});

function sanitize(str){
 return (str||"douyin_media")
 .replace(/[\\\\/:*?"<>|]/g,"")
 .slice(0,80);
}

function escapeHtml(str){
 return (str||"")
 .replace(/&/g,"&amp;")
 .replace(/</g,"&lt;")
 .replace(/>/g,"&gt;");
}

load();


window.addEventListener("DOMContentLoaded",()=>{

 const modal=document.getElementById("disclaimerModal");
 const agree=document.getElementById("agreeCheck");
 const startBtn=document.getElementById("startDownloadBtn");
 const cancelBtn=document.getElementById("closeModalBtn");
 const downloadBtn=document.getElementById("downloadBtn");

 if(!modal) return;

 window.__douyinDisclaimerAccepted=false;

 startBtn.disabled=true;

 agree.addEventListener("change",()=>{

    if(agree.checked){
       startBtn.disabled=false;
       startBtn.classList.add("enabled");
    }else{
       startBtn.disabled=true;
       startBtn.classList.remove("enabled");
    }

 });

 cancelBtn.addEventListener("click",()=>{

    modal.classList.add("hidden");

 });

 startBtn.addEventListener("click",()=>{

    if(!agree.checked) return;

    window.__douyinDisclaimerAccepted=true;

    modal.classList.add("hidden");

    downloadBtn.click();

    setTimeout(()=>{
       window.__douyinDisclaimerAccepted=false;
    },1000);

 });

});
