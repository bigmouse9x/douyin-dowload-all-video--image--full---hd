
document.getElementById("saveTab").addEventListener("click",async()=>{
 const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
 chrome.storage.local.set({douyinTabId:tab.id});
 alert("Douyin tab saved!");
});
document.getElementById("openDashboard").addEventListener("click",()=>{
 chrome.tabs.create({url:chrome.runtime.getURL("dashboard.html")});
});
