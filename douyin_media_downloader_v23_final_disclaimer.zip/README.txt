
DOUYIN DOWNLOADER V14

FIXED:
- Download button not working
- Removed broken ZIP dependency
- Faster batch downloads

HOW IT WORKS:
- Downloads all selected media automatically
- No ZIP generation
- Works reliably with Chrome extension CSP

IMPORTANT:
If Chrome asks where to save each file:
Chrome Settings -> Downloads
Turn OFF:
"Ask where to save each file before downloading"
